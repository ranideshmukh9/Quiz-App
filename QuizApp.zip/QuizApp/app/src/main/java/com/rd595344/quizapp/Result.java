package com.rd595344.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Result extends AppCompatActivity {
    TextView name,score,right,wrong,accuracy;

    Button again,exit;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        name = findViewById(R.id.txt_name);
        score = findViewById(R.id.txt_score);
        right = findViewById(R.id.txt_right);
        wrong = findViewById(R.id.txt_wrong);
        accuracy = findViewById(R.id.txt_per);

        exit = findViewById(R.id.btn_exit);
        again = findViewById(R.id.btn_again);

        Intent intent = getIntent();
        String user=intent.getStringExtra(QuizActivity.str_name);
        String sc=intent.getStringExtra(QuizActivity.str_score);
        String rt=intent.getStringExtra(QuizActivity.str_right);
        String wr=intent.getStringExtra(QuizActivity.str_wrong);
        String total=intent.getStringExtra(QuizActivity.str_total);

        name.setText(user);
        score.setText(sc+"/"+total);
        right.setText(rt);
        wrong.setText(wr);

        int size = Integer.parseInt(total);
        int correct = Integer.parseInt(sc);

        int per = (correct*100)/size;
        accuracy.setText(per+"  %");

        again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Result.this,MainActivity.class));
                finish();
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }



}