package com.rd595344.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    TextView question_text,indicator;
    LinearLayout container;
    Button next;

    int score=0;
    int position=0;
    int count=0;
    int right=0;
    int wrong=0;
    int size=0;

    public static final String str_score="score";
    public static final String str_right="right";
    public static final String str_wrong="wrong";
    public static final String str_total="total";
    public static final String str_name="name";

    String user;

    private List<Questions> list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        question_text = findViewById(R.id.question_txt);
        indicator = findViewById(R.id.indicator);
        container = findViewById(R.id.option_linear);
        next = findViewById(R.id.next);
        list = new ArrayList<>();

        next.setEnabled(false);
        next.setAlpha(0.5f);
        start_quiz();

        Intent intent = getIntent();
        user=intent.getStringExtra(MainActivity.user);

    }
    private void start_quiz(){
        list = new ArrayList<>();

        list.add(new Questions("Number of primitive data types in Java are ?", "6", "7", "8", "9", "8"));
        list.add(new Questions("What is the size of float and double in java ?", "32 & 64", "32 & 32", "64 & 64", "64 & 32", "32 & 64"));
        list.add(new Questions("When is the object created in java with new keyword ?", "Compile Time", "Depends", "Runtime", "None", "Runtime"));
        list.add(new Questions("compareTo() returns ?", "true", "int", "false", "None", "int"));
        list.add(new Questions("To which of the following does the class string belong to", "java.lang", "java.awt", "java.applet", "java.string", "java.lang"));
        list.add(new Questions("Which of the following are some common RDBMS in use ?", "Oracle", "MySql", "HeidiSQL", "All of them", "All of them"));
        list.add(new Questions("What does BLOB in SQL stand for ?", "Binary Large Objects", "Big Large Objects", "Binary Language for Objects", "None of the Above", "Binary Large Objects"));
        list.add(new Questions("Which of the following commands is used to delete all rows and free up space from a table ?", "Truncate", "Drop", "Delete", "Alter", "Truncate"));
        list.add(new Questions("Which of the following commands are a part of Data Control Language ?", "Revoke", "Grant", "A & B", "None", "A & B"));
        list.add(new Questions("What are rows of a relation known as ?", "Degree", "Entity", "Tuple", "None", "Tuple"));
        list.add(new Questions("How many operations are considered to be the most basic SQL operations ?", "4", "3", "2", "1", "4"));
        list.add(new Questions("Which of the following is not a SQL command ?", "Delete", "Select", "Where", "Order By", "Delete"));

        size=list.size();

        if (list.size() > 0) {
            loadQuestion(question_text, 0, list.get(position).getQuestion());

            for (int k = 0; k < 4; k++) {
                container.getChildAt(k).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        checkAnswer((Button) view);
                    }
                });
            }

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    next.setEnabled(false);
                    next.setAlpha(0.5f);
                    enable(true);
                    position++;
                    if (position == list.size()) {
                        Intent intent = new Intent(QuizActivity.this,Result.class);
                        intent.putExtra(str_name,user);
                        intent.putExtra(str_score,""+score);
                        intent.putExtra(str_right,""+right);
                        intent.putExtra(str_wrong,""+wrong);
                        intent.putExtra(str_total,""+size);
                        startActivity(intent);
                        finish();

                    } else {
                        count = 0;
                        loadQuestion(question_text, 0, list.get(position).getQuestion());
                    }
                }
            });
        } else {
            Toast.makeText(QuizActivity.this, "No Data Found", Toast.LENGTH_SHORT).show();
        }
    }


    //Question load function

    private void loadQuestion(View view , int value, String data){
        view.animate().alpha(value).scaleX(value).scaleY(value).setDuration(200)
                .setStartDelay(100).setInterpolator(new DecelerateInterpolator())
                .setListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animator) {
                        if (value==0 && count<4){
                            loadQuestion(container.getChildAt(count),0,data);
                            String option="";
                            if (count==0)
                                option= list.get(position).getOption1();
                            else if (count==1)
                                option= list.get(position).getOption2();
                            else if (count==2)
                                option= list.get(position).getOption3();
                            else if (count==3)
                                option= list.get(position).getOption4();

                            loadQuestion(container.getChildAt(count),0,option);
                            count++;

                        }
                    }

                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onAnimationEnd(Animator animator) {
                        if(value==0) {
                            try {
                                ((TextView) view).setText(data);
                                indicator.setText(position+1 + "/" + list.size());
                            } catch (ClassCastException e) {
                                ((Button) view).setText(data);
                            }
                            view.setTag(data);
                            loadQuestion(view,1,data);
                        }
                    }
                    @Override
                    public void onAnimationCancel(Animator animator) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animator) {

                    }
                });
    }
    private void checkAnswer(Button select){
        enable(false);
        next.setEnabled(true);
        next.setAlpha(1);
        if (select.getText().toString().equals(list.get(position).getAnswer())){
            select.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#001842")));
            score++;
            right++;
        }
        else {
            select.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#001842")));
            wrong++;
        }
    }

    //Button Enable function

    private void enable(Boolean enable){
        for (int i=0;i<4;i++){
            container.getChildAt(i).setEnabled(enable);
            container.getChildAt(i).setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#63A4FF")));

        }
    }
}